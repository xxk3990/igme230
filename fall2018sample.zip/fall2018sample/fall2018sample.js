/* Don't use <script> tags in a linked js file! */
